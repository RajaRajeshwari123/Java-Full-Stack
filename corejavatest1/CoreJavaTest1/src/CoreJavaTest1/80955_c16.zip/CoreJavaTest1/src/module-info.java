/**
 * 
 */
/**
 * 
 */
module CoreJavaTest1 {
}