package CoreJavaTest1.Question1;

public class VehicleUnavailableException extends Exception {
	   public VehicleUnavailableException(String message) 
	   { 
		   super(message);
		   }
	

}
