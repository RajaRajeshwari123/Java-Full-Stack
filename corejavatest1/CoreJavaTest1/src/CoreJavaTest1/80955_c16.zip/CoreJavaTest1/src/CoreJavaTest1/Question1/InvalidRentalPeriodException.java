package CoreJavaTest1.Question1;

public class InvalidRentalPeriodException extends Exception {
	   public InvalidRentalPeriodException(String message)
	   { 
		   super(message); 
		   }
	}
